#!/usr/bin/env bash
# Minimal SOLEN shared helpers for scripts

# Do NOT set -e/-u here; these files are sourced by scripts that manage shell opts

solen_ts() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
solen_host() { hostname 2>/dev/null || uname -n; }

# Flags: default to verify-by-default, dry-run unless --yes is given
solen_init_flags() {
  : "${SOLEN_FLAG_YES:=0}"
  : "${SOLEN_FLAG_JSON:=${SOLEN_JSON:-0}}"
  : "${SOLEN_FLAG_DRYRUN:=1}"
  if [ "${SOLEN_FLAG_YES}" = "1" ]; then SOLEN_FLAG_DRYRUN=0; fi
}

# Parse a common flag; echo nothing, return 0 if handled
solen_parse_common_flag() {
  case "$1" in
    --yes|-y) SOLEN_FLAG_YES=1; SOLEN_FLAG_DRYRUN=0; return 0 ;;
    --dry-run) SOLEN_FLAG_DRYRUN=1; return 0 ;;
    --json) SOLEN_FLAG_JSON=1; return 0 ;;
  esac
  return 1
}

# Styled messages
solen_info() { echo -e "\033[0;36mℹ️  $*\033[0m"; }
solen_ok()   { echo -e "\033[0;32m✅ $*\033[0m"; }
solen_warn() { echo -e "\033[0;33m⚠️  $*\033[0m"; }
solen_err()  { echo -e "\033[0;31m❌ $*\033[0m" 1>&2; }

# Emit a single JSON record with optional extra fields
# Usage: solen_json_record <status> <summary> <actions_text> <extra_json_fields>
solen_json_record() {
  local status="$1" summary="$2" actions_text="${3:-}" extra="${4:-}"
  # Escape JSON
  _esc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
  local host; host="$(solen_host)"
  # Convert actions_text (newline-separated) to JSON array
  local actions_json="[]"
  if [ -n "$actions_text" ]; then
    actions_json="["
    local first=1
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      local e; e="$(_esc "$line")"
      if [ $first -eq 0 ]; then actions_json+=" ,"; else first=0; fi
      actions_json+="\"$e\""
    done <<EOF
${actions_text}
EOF
    actions_json+="]"
  fi
  printf '{"status":"%s","summary":"%s","ts":"%s","host":"%s","actions":%s%s}%s' \
    "$(_esc "$status")" "$(_esc "$summary")" "$(solen_ts)" "$(_esc "$host")" "$actions_json" \
    "${extra:+,${extra}}" "\n"
}

