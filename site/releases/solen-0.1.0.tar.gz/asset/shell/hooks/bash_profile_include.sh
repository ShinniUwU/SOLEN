# >>> SOLEN BASH_PROFILE_INCLUDE (do not edit) >>>
# Ensure interactive config is loaded for login shells
if [ -f "$HOME/.bashrc" ]; then
  . "$HOME/.bashrc"
fi
# <<< SOLEN BASH_PROFILE_INCLUDE (managed) <<<
